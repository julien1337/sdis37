﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace Projet_SDIS37
{
    public class Database
    {
        private string _dataSource = Properties.Settings.Default.DataSource;
        private string _username = Properties.Settings.Default.Username;
        private string _password = Properties.Settings.Default.Password;
        private string _database = Properties.Settings.Default.Database;
        public MySqlConnection _connexion;

        public Database()
        {
            try
            {
                string chaine = "datasource=" + _dataSource + ";username=" + _username + ";password=" + _password + ";Database=" + _database;
                _connexion = new MySqlConnection(chaine);
            }
            catch(Exception e)
            {
                throw new Exception(e.Message);
            }
       
        }

        public void ExecuteStoredProcedure(string nameStoredProcedure)
        {
            MySqlCommand storedProcedure = new MySqlCommand(nameStoredProcedure, _connexion);
            _connexion.Open();
            storedProcedure.CommandType = System.Data.CommandType.StoredProcedure;
            try
            {
                storedProcedure.ExecuteNonQuery();
            }
            catch(Exception e)
            {
                _connexion.Close();
                throw new Exception(e.Message);
            }
        }

        public DataSet ExecuteStoredProcedure(string nameStoredProcedure, List<MySqlParameter> sqlParameters)
        {
            _connexion.Open();
            MySqlCommand storedProcedure = new MySqlCommand(nameStoredProcedure, _connexion);
            storedProcedure.CommandType = System.Data.CommandType.StoredProcedure;
            storedProcedure.Parameters.AddRange(sqlParameters.ToArray());

            MySqlDataAdapter da = new MySqlDataAdapter();
            da.SelectCommand = storedProcedure;

            DataSet ds = new DataSet();
            
            da.Fill(ds);

            _connexion.Close();
            return ds;
        }

    }
}
