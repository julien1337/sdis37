﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using System.Data;

namespace Projet_SDIS37
{
    /// <summary>
    /// Logique d'interaction pour Login.xaml
    /// </summary>
    public partial class Login : UserControl, ISwitchable
    {
        private Database database = new Database();

        public Login()
        {
            InitializeComponent();
        }

        private void SubmitLogin(object sender, RoutedEventArgs e)
        {
            List<MySqlParameter> sqlParameters = new List<MySqlParameter>();
            sqlParameters.Add(new MySqlParameter { MySqlDbType = MySqlDbType.VarChar, ParameterName = "mail", Value = txtEmail.Text });  
            sqlParameters.Add(new MySqlParameter { MySqlDbType = MySqlDbType.VarChar, ParameterName = "pass", Value = txtPassword.Password });
            DataSet resultLogin = database.ExecuteStoredProcedure("PROC_LOGIN", sqlParameters);

            object result = resultLogin.Tables[0].Rows[0].ItemArray[0];
            if(result.ToString() == "1")
            {
                App.Current.Properties["userEmail"] = txtEmail.Text;
                if (txtPassword.Password == "12345")
                {
                    loginLabel.Visibility = Visibility.Hidden;
                    txtEmail.Visibility = Visibility.Hidden;
                    txtPassword.Visibility = Visibility.Hidden;
                    connectButton.Visibility = Visibility.Hidden;
                    txtError.Visibility = Visibility.Hidden;
                    changePass.Visibility = Visibility.Visible;
                }
                else
                {
                    Switcher.Switch(new Home());
                }
            }
            txtError.Text = "Compte inconnu. Veuillez réessayer.";
        }

        public void UtilizeState(object state)
        {
            throw new NotImplementedException();
        }

        private void SubmitOkPass(object sender, RoutedEventArgs e)
        {
            List<MySqlParameter> sqlParameters = new List<MySqlParameter>();
            sqlParameters.Add(new MySqlParameter { MySqlDbType = MySqlDbType.VarChar, ParameterName = "email", Value = txtEmail.Text });
            sqlParameters.Add(new MySqlParameter { MySqlDbType = MySqlDbType.VarChar, ParameterName = "pass", Value = PassBox.Password });
            DataSet resultLogin = database.ExecuteStoredProcedure("PROC_CHANGE_PASS", sqlParameters);

            Switcher.Switch(new Home());
        }
    }
}
