﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;

using MySql.Data.MySqlClient;

namespace Projet_SDIS37
{
    /// <summary>
    /// Logique d'interaction pour Caserne.xaml
    /// </summary>
    public partial class Caserne : UserControl, ISwitchable
    {
        private Database bdd = new Database();

        public Caserne()
        {
            InitializeComponent();
        }
             
        public void UtilizeState(object state)
        {
            throw new NotImplementedException();
        }

        // BOUTON RECHERCHER CASERNE
        private void SubmitResearch(object sender, RoutedEventArgs e)
        {
            if(idCaserne.Text != "" || nomCaserne.Text != "")
            {
                try
                {
                    List<MySqlParameter> sqlParameters = new List<MySqlParameter>();
                    if (idCaserne.Text != "")
                    {
                        sqlParameters.Add(new MySqlParameter { MySqlDbType = MySqlDbType.Int32, ParameterName = "id", Value = idCaserne.Text });
                        sqlParameters.Add(new MySqlParameter { MySqlDbType = MySqlDbType.VarChar, ParameterName = "nom", Value = nomCaserne.Text });
                    }
                    else
                    {
                        sqlParameters.Add(new MySqlParameter { MySqlDbType = MySqlDbType.VarChar, ParameterName = "nom", Value = nomCaserne.Text });
                        sqlParameters.Add(new MySqlParameter { MySqlDbType = MySqlDbType.Int32, ParameterName = "id", Value = -1 });
                    }

                    DataTable dt1 = bdd.ExecuteStoredProcedure("PROC_SELECT_COORD_CASERNE", sqlParameters).Tables[0];
                    DataTable dt2 = bdd.ExecuteStoredProcedure("PROC_SELECT_COORD_CASERNE", sqlParameters).Tables[1];
                    DataTable dt3 = bdd.ExecuteStoredProcedure("PROC_SELECT_COORD_CASERNE", sqlParameters).Tables[2];
                    DataTable dt4 = bdd.ExecuteStoredProcedure("PROC_SELECT_COORD_CASERNE", sqlParameters).Tables[3];

                    DataTable total = new DataTable();
                    total.Columns.Add("CASERNE :");
                    total.Merge(dt1, false, MissingSchemaAction.Add);
                    total.Columns.Add("POMPIER VOLONTAIRE :");
                    total.Merge(dt2, false, MissingSchemaAction.Add);
                    total.Columns.Add("JEUNES SAPEURS POMPIERS :");
                    total.Merge(dt3, false, MissingSchemaAction.Add);
                    total.Columns.Add("POMPIERS PROFESSIONNELS :");
                    total.Merge(dt4, false, MissingSchemaAction.Add);

                    resultCaserne.ItemsSource = total.DefaultView;
                    resultCaserne.Visibility = Visibility.Visible;
                    closeButton.Visibility = Visibility.Visible;


                    idCaserne.Text = "";
                    nomCaserne.Text = "";
                    telCaserne.Text = "";
                    adrCaserne.Text = "";
                    villeCaserne.Text = "";
                    typeCaserne.Text = "";
                }

                catch(Exception error)
                {
                    throw new Exception(error.Message);
                }

                errorMessage.Visibility = Visibility.Hidden;
            }

            else
            {
                errorMessage.Visibility = Visibility.Visible;
                errorMessage.Content = "Vous devez remplir le champs ID ou Nom pour rechercher une caserne.";
            }
        }

        // BOUTON AJOUTER CASERNE
        private void SubmitInsert(object sender, RoutedEventArgs e)
        {
            if (nomCaserne.Text != "" && telCaserne.Text != "" && adrCaserne.Text != "" && villeCaserne.Text != "" && (typeCaserne.Text == "CS" || typeCaserne.Text == "CSP"))
            {
                try
                {
                    List<MySqlParameter> sqlParameters = new List<MySqlParameter>();
                    sqlParameters.Add(new MySqlParameter { MySqlDbType = MySqlDbType.VarChar, ParameterName = "caserne_nom", Value = nomCaserne.Text });
                    sqlParameters.Add(new MySqlParameter { MySqlDbType = MySqlDbType.VarChar, ParameterName = "caserne_tel", Value = telCaserne.Text });
                    sqlParameters.Add(new MySqlParameter { MySqlDbType = MySqlDbType.VarChar, ParameterName = "caserne_adr", Value = adrCaserne.Text });
                    sqlParameters.Add(new MySqlParameter { MySqlDbType = MySqlDbType.VarChar, ParameterName = "caserne_ville", Value = villeCaserne.Text });
                    sqlParameters.Add(new MySqlParameter { MySqlDbType = MySqlDbType.VarChar, ParameterName = "caserne_type", Value = typeCaserne.Text });

                    bdd.ExecuteStoredProcedure("PROC_INSERT_CASERNE", sqlParameters);

                    idCaserne.Text = "";
                    nomCaserne.Text = "";
                    telCaserne.Text = "";
                    adrCaserne.Text = "";
                    villeCaserne.Text = "";
                    typeCaserne.Text = "";

                    MessageBox.Show("Caserne ajouté !");
                }

                catch (Exception error)
                {
                    throw new Exception(error.Message);
                }

                errorMessage.Visibility = Visibility.Hidden;
            }

            else
            {
                errorMessage.Visibility = Visibility.Visible;
                errorMessage.Content = "Vous devez remplir tous les champs sauf ID pour insérer une caserne.";
            }
        }

        // BOUTON MODIFIER CASERNE
        private void SubmitUpdate(object sender, RoutedEventArgs e)
        {
            if(idCaserne.Text != "" && (typeCaserne.Text == "CS" || typeCaserne.Text == "CSP"))
            {
                try
                {
                    List<MySqlParameter> sqlParameters = new List<MySqlParameter>();
                    sqlParameters.Add(new MySqlParameter { MySqlDbType = MySqlDbType.Int32, ParameterName = "caserne_id", Value = idCaserne.Text});
                    sqlParameters.Add(new MySqlParameter { MySqlDbType = MySqlDbType.VarChar, ParameterName = "caserne_nom", Value = nomCaserne.Text });
                    sqlParameters.Add(new MySqlParameter { MySqlDbType = MySqlDbType.VarChar, ParameterName = "caserne_tel", Value = telCaserne.Text });
                    sqlParameters.Add(new MySqlParameter { MySqlDbType = MySqlDbType.VarChar, ParameterName = "caserne_adr", Value = adrCaserne.Text });
                    sqlParameters.Add(new MySqlParameter { MySqlDbType = MySqlDbType.VarChar, ParameterName = "caserne_ville", Value = villeCaserne.Text });
                    sqlParameters.Add(new MySqlParameter { MySqlDbType = MySqlDbType.VarChar, ParameterName = "caserne_type", Value = typeCaserne.Text });

                    bdd.ExecuteStoredProcedure("PROC_UPDATE_CASERNE", sqlParameters);

                    idCaserne.Text = "";
                    nomCaserne.Text = "";
                    telCaserne.Text = "";
                    adrCaserne.Text = "";
                    villeCaserne.Text = "";
                    typeCaserne.Text = "";

                    MessageBox.Show("Caserne modifié !");
                }

                catch (Exception error)
                {
                    throw new Exception(error.Message);
                }

                errorMessage.Visibility = Visibility.Hidden;
            }

            else
            {
                errorMessage.Visibility = Visibility.Visible;
                errorMessage.Content = "Vous devez remplir au moins le champs ID afin de modifier une caserne.";
            }
        }

        // BOUTON SUPPRIMER UNE CASERNE   
        private void SubmitDelete(object sender, RoutedEventArgs e)
        {
            if (idCaserne.Text != "" || nomCaserne.Text != "") // CHECK EMPTY FIELD
            {
                MessageBoxResult messageBoxResult = System.Windows.MessageBox.Show("¨Voulez vous vraiment supprimer cette caserne ?", "Delete Confirmation", System.Windows.MessageBoxButton.YesNo);
                if (messageBoxResult == MessageBoxResult.Yes)
                {
                    try
                    {
                        List<MySqlParameter> sqlParameters = new List<MySqlParameter>();
                        if (idCaserne.Text != "")
                        {
                            sqlParameters.Add(new MySqlParameter { MySqlDbType = MySqlDbType.Int32, ParameterName = "caserne_id", Value = idCaserne.Text });
                            sqlParameters.Add(new MySqlParameter { MySqlDbType = MySqlDbType.VarChar, ParameterName = "caserne_nom", Value = nomCaserne.Text });
                        }
                        else
                        {
                            sqlParameters.Add(new MySqlParameter { MySqlDbType = MySqlDbType.VarChar, ParameterName = "caserne_nom", Value = nomCaserne.Text });
                            sqlParameters.Add(new MySqlParameter { MySqlDbType = MySqlDbType.Int32, ParameterName = "caserne_id", Value = -1 });
                        }

                        bdd.ExecuteStoredProcedure("PROC_DELETE_CASERNE", sqlParameters);

                        idCaserne.Text = "";
                        nomCaserne.Text = "";
                        telCaserne.Text = "";
                        adrCaserne.Text = "";
                        villeCaserne.Text = "";
                        typeCaserne.Text = "";

                        MessageBox.Show("Caserne supprimé !", "Done");
                    }


                    catch (Exception error)
                    {
                        throw new Exception(error.Message);
                    }

                }

                errorMessage.Visibility = Visibility.Hidden;
            }

            else
            {
                errorMessage.Visibility = Visibility.Visible;
                errorMessage.Content = "Vous devez remplir le champs ID ou Nom pour supprimer une caserne.";
            }
        }

        private void SubmitBack(object sender, RoutedEventArgs e)
        {
            Switcher.Switch(new Home());
        }

        private void SubmitClose(object sender, RoutedEventArgs e)
        {
            resultCaserne.Visibility = Visibility.Hidden;
            closeButton.Visibility = Visibility.Hidden;
        }
    }
}
